SHADOW QUEST — Android project (প্রাথমিক সংস্করণ)

এই ZIP-এ Android Studio/Gradle project source আছে। এটি এখনো APK নয় এবং Play Store-এ সরাসরি upload করা যাবে না।

মোবাইল দিয়ে APK বানানোর সহজ পথ:
1. ZIP extract করে GitHub-এ নতুন repository তৈরি করুন।
2. সব ফাইল repository-র root-এ upload করুন (ফোল্ডারের ভেতরের ফাইলসহ)।
3. GitHub > Actions খুলে "Build Shadow Quest APK" workflow চালান।
4. Workflow শেষ হলে Artifacts থেকে "Shadow-Quest-debug-APK" download করুন।
5. APK ফোনে install করে পরীক্ষা করুন।

Play Store-এর জন্য:
- Debug APK নয়, signed release AAB লাগবে।
- Play Console account, identity verification, store listing, privacy/data safety details এবং app testing প্রয়োজন।
- Personal developer account-এর ক্ষেত্রে ১২ জন tester-কে closed test-এ টানা ১৪ দিন opt-in থাকতে হয় (Google-এর বর্তমান নিয়ম)।
- এই প্রজেক্টে এখনো online multiplayer নেই; দুইজন একই ডিভাইসে খেলতে পারে।
- প্রকাশের আগে app icon, screenshots, privacy policy, content rating ও release signing যোগ করতে হবে।

Package ID: com.shadowquest.game
Target SDK: 36
Version: 1.0 (1)
